export interface QueryInput {
  question: string;
}

export interface QueryResult {
  text: string;
  source: string;
}
