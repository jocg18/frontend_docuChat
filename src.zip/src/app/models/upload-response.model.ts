export interface UploadResponse {
  success: boolean;
  message: string;
  documentId?: string;
}
