export interface DocumentMetadata {
  filename: string;
  content: string;
  createdAt?: string;
}
