export interface QueryRequest {
    query: string;
}
