export interface QueryResponse {
    response: string;
}
