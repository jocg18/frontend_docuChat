import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';

@Component({
    selector: 'app-search', // este es el nombre correcto según tu app.component.html
    standalone: true,
    imports: [CommonModule, FormsModule, MatInputModule, MatButtonModule],
    templateUrl: './chatbot.component.html',
    styleUrls: ['./chatbot.component.css']
    })
    export class ChatbotComponent {
    question: string = '';
    response: string = '';
    loading: boolean = false;

    sendQuestion() {
        if (!this.question.trim()) {
        this.response = 'Por favor escribe una pregunta.';
        return;
        }

        this.loading = true;
        fetch('http://127.0.0.1:3000/api/query', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ question: this.question })
        })
        .then(resp => {
            if (!resp.ok) {
            throw new Error('Error al consultar el backend');
            }
            return resp.json();
        })
        .then(data => {
            this.response = data.response;
            this.loading = false;
        })
        .catch(err => {
            this.response = `Error: ${err.message}`;
            this.loading = false;
        });
    }
}
