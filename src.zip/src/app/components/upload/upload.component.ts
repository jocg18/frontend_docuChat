import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressBarModule } from '@angular/material/progress-bar';

@Component({
  selector: 'app-upload',
  standalone: true,
  imports: [CommonModule, MatCardModule, MatButtonModule, MatProgressBarModule],
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent {
  selectedFile: File | null = null;
  message: string = '';
  loading: boolean = false;

  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedFile = input.files[0];
      this.message = '';
    }
  }

  uploadFile() {
    if (!this.selectedFile) {
      this.message = 'Selecciona un archivo primero';
      return;
    }

    this.loading = true;
    const formData = new FormData();
    formData.append('file', this.selectedFile);

    fetch('http://127.0.0.1:3000/api/upload', {
      method: 'POST',
      body: formData
    })
    .then(async resp => {
      this.loading = false;
      if (resp.ok) {
        const data = await resp.json();
        this.message = `✅ Archivo "${this.selectedFile?.name}" cargado con éxito.`;
      } else {
        const err = await resp.json().catch(() => null);
        throw new Error(err?.details || 'Error al subir archivo');
      }
    })
    .catch(err => {
      this.loading = false;
      this.message = err.message;
    });
  }
}
